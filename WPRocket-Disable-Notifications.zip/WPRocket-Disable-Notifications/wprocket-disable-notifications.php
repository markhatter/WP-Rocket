<?php
/*
Plugin Name: WPRocket Disable Notifications
Description: Removes admin warnings for WP Rocket files not being writeable
Version:     1.0
Author:      Mark Hatter
Author URI:  http://www.markhatter.co.uk
License:     GPL2 etc
*/

if(!function_exists('disable_notices')){
    function disable_notices(){
   		remove_action( 'admin_notices', 'rocket_warning_htaccess_permissions' );
		remove_action( 'admin_notices', 'rocket_warning_cache_dir_permissions' );
    }
}
add_action( 'init', 'disable_notices');
?>